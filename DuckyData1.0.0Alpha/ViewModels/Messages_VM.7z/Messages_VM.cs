﻿using DuckyData1._0._0Alpha.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DuckyData1._0._0Alpha.ViewModels
{
    public static partial class ConfigureMaps
    {
        public static void ForMessage()
        {
            AutoMapper.Mapper.CreateMap<Message, MessageAdd>();
            AutoMapper.Mapper.CreateMap<Message, MessageBase>();
            AutoMapper.Mapper.CreateMap<Message, MessageEdit>();
            AutoMapper.Mapper.CreateMap<MessageAdd, Message>();
            AutoMapper.Mapper.CreateMap<MessageAdd, Message>();
            AutoMapper.Mapper.CreateMap<MessageAdd, MessageBase>();
            AutoMapper.Mapper.CreateMap<MessageBase, Message>();
            AutoMapper.Mapper.CreateMap<MessageBase, MessageEditForm>();
            AutoMapper.Mapper.CreateMap<MessageEdit, MessageEditForm>();
        }
    }

    public class MessageList
    {
        public int Id { get; set; }
        public string Subject { get; set; }
    }
    public class MessageAddForm
    {

        [HiddenInput]
        public DateTime SentDate { get; set; }

        [Required]
        [StringLength(500)]
        public string Recipient { get; set; }

        [Required]
        [StringLength(100)]
        public string Subject { get; set; }

        [Required]
        public string Body { get; set; }

        //attachment attributes
        public byte[] Attachment { get; set; }

        public string ContentType { get; set; }

        public string ContentName { get; set; }

    }

    public class MessageAdd
    {

        [HiddenInput]
        public DateTime SentDate { get; set; }

        [HiddenInput]
        public string UserName { get; set; }

        public string UserId { get; set; }
        

        [Required]
        [StringLength(500)]
        public string Recipient { get; set; }

        [Required]
        [StringLength(100)]
        public string Subject { get; set; }

        [Required]
        public string Body { get; set; }

        public HttpPostedFileBase Attachments { get; set; }

        public bool viewed { get; set; }
    }

    public class MessageBase : MessageAdd
    {

        public MessageBase()
        {
            url = HttpContext.Current.Request.Url.GetLeftPart(System.UriPartial.Authority);
        }
        public int Id { get; set; }
        public string ContentType { get; set; }
        public string ContentName { get; set; }
        public byte[] Attachment { get; set; }

        private string url = "";
        public string AttachUrl
        {
            get
            {
                return string.Format("{0}/image/Message/attachment/{1}", url, Id);
            }
        }

    }


    public class MessageEdit
    {
        [HiddenInput]
        public int Id { get; set; }


        [HiddenInput]
        public string UserName { get; set; }

        [HiddenInput]
        public DateTime SentDate { get; set; }

        [Required]
        [StringLength(500)]
        public string Recipient { get; set; }

        [Required]
        [StringLength(100)]
        public string Subject { get; set; }

        [Required]
        public string Body { get; set; }


        public bool viewed { get; set; }

        //attachment attributes
        public byte[] Attachment { get; set; }

        public string ContentType { get; set; }

        public string ContentName { get; set; }

    }

    public class MessageEditForm
    {
        [HiddenInput]
        public int Id { get; set; }

        [HiddenInput]
        public DateTime SentDate { get; set; }

        [Required]
        [StringLength(500)]
        public string Recipient { get; set; }

        [Required]
        [StringLength(100)]
        public string Subject { get; set; }

        [Required]
        public string Body { get; set; }

        [Required]
        public string UserId { get; set; }

        public bool viewed { get; set; }

        //attachment attributes
        public byte[] Attachment { get; set; }

        public string ContentType { get; set; }

        public string ContentName { get; set; }
    }
}
